This IPython notebook Day3.ipynb does not require any additional
programs.
